'''
This is a simple script
'''
def cap_text(text):
    '''
    Input: A text/sentence
    Output: Capitalized text
    '''
    return text.title()