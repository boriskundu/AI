def mysub_report():
	print('Hey! I am a report (module) in sub package')