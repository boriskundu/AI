def mymain_report():
	print('Hey! I am a report (module) in main package')