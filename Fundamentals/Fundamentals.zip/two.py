import one
print('TOP LEVEL of two.py')
one.func()

if __name__ == '__main__':
	print('two.py is running directly')
	## RUN SCRIPT LOGIC SAY CALLING FUNCTIONS DEFINED ABOVE
else:
	print('two.py is running indirectly via import')