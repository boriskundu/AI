from mymodule import my_func
from MyMainPackage import mymain
from MyMainPackage.SubPackage import mysub

my_func()
mymain.mymain_report()
mysub.mysub_report()

