'''
A very simple python script
'''
def my_func():
    '''
    A simple function
    '''
    first = 1
    second = 2
    print(first)
    print(second)

if __name__ == '__main__':
    my_func()
