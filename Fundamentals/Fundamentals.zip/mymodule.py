def my_func():
	print('I am running from mymodule')
